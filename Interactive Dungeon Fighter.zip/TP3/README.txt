PROJECT TITLE: DUNGEON FIGHTER 112

Requirements:
- cmu_graphics
- PIL (images)

robot.png (player)
blue mob.png (melee enemy)
green mob.png (ranged enemy)
red mob.png (boss)
floor image.png (floor texture)
menu background.png (title screen)

Description:
A top-down dungeon crawler game where the main character is spawned in a procedurally-generated dungeon. This dungeon has randomly sized/random number of rooms and corridors, and each room is unique. Each stage spawns enemies and the player must kill all enemies to move onto the next stage. Some enemy attacks include the enemy shooting at you or running into you to deal damage. 

Once the player is past stage 3, a boss fight occurs. This boss fight spawns a brand new mob in a square grid, and the player is tasked to fight the mob and it's attack patterns (which change by health). Ultimately beating the boss implies that the game is won!

Run Instructions:
- Run main.py on preferred editor and use the required libraries. The image files must also be downloaded to ensure functionality

Controls: 
- WASD is used to move around
	-> W = up, S = down, A = left, D = right
- F is used to shoot bullets
- Mouse position is used to aim bullet direction
- Mouse is used to interact with UI