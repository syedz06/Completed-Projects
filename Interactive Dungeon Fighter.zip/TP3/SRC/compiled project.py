from cmu_graphics import *
import math
import copy
import random
import time    
from PIL import Image

# used to run cmu graphics on my computer -> location will vary on devices
import os
os.chdir('C:/Users/zsyed/OneDrive/Desktop/15 112/TP3')

class Player: #draws player, stores location and movement data
    def __init__(self,app):
        spawnRoom = random.choice(app.map.rooms)
        centerX, centerY = spawnRoom.getCenter()

        # store coordinates
        self.mapRow = self.mapCol = app.map.viewportSize/2
        self.x = app.width/2
        self.y = app.height/2
        self.mapRow = float(centerY)
        self.mapCol = float(centerX)

        self.playerHeight = 30
        self.playerWidth = 30
        self.movementSpeed = 0.4
        self.dx = self.movementSpeed
        self.dy = self.movementSpeed
        
        self.color = 'teal'
        self.bulletsRemaining = 200
        self.bulletsInitial = 200
        self.enemiesKilled = 0
        self.health = 100
        self.initialHealth = 100

    def getCenter(self):
        centerX = self.x + self.playerWidth//2
        centerY = self.y + self.playerHeight//2
        return (int(centerX), int(centerY))

    def draw(self,app):
        # line to see where bullet is headed
        drawLine(self.x, self.y, app.mouseX, app.mouseY, fill = 'red',
                 lineWidth = 4, arrowEnd = True, dashes=True, opacity = 50)
        
        # https://store.line.me/stickershop/product/3254074/en
        playerImage = CMUImage(Image.open('robot.png'))
        drawImage(playerImage, self.x, self.y, align='center')
                 
    def move(self, app, key, gameMap):
        oldRow = self.mapRow
        oldCol = self.mapCol
        
        diagonalMove = ('w' in key or 's' in key) and ('a' in key or 'd' in key)

        # make sure speed is consistent regardless of directional movement
        # if moving diagonally, adjust (pythagorean) 1/sqrt(2) = .707
        if diagonalMove:
            speedMultiplier = 0.707
        else:
            speedMultiplier = 1

        if 'w' in key:
            self.mapRow -= self.dy * speedMultiplier
        if 's' in key:
            self.mapRow += self.dy * speedMultiplier
        if 'a' in key: 
            self.mapCol -= self.dx * speedMultiplier
        if 'd' in key:
            self.mapCol += self.dx * speedMultiplier
        
        # movement is completely different for boss stage as it is a grid only
        if isinstance(gameMap,BossMap):
            self.x = self.mapCol * gameMap.cellWidth
            self.y = self.mapRow * gameMap.cellHeight

            self.speed = 5

            checkRow = int(self.mapRow)
            checkCol = int(self.mapCol)

            # make sure player stays in bounds
            if ((not (1 <= checkRow < gameMap.rows-1)) or 
                (not (1 <= checkCol < gameMap.cols-1)) or
                (gameMap.board[checkRow][checkCol] == 'black')):
                self.mapRow = oldRow
                self.mapCol = oldCol
                self.x = self.mapCol * gameMap.cellWidth
                self.y = self.mapRow * gameMap.cellHeight

        else:

            # Ensure we stay within map boundaries
            self.mapRow = max(0, min(gameMap.rows - 1, self.mapRow))
            self.mapCol = max(0, min(gameMap.cols - 1, self.mapCol))

            # need to make sure if movement is valid
            # -> in bounds and not running into a wall
            checkRow = int(self.mapRow)
            checkCol = int(self.mapCol)

            # if not a valid movement, undo the move
            if ((not (0 <= checkRow < gameMap.rows)) or 
                (not (0 <= checkCol < gameMap.cols)) or  
                    (gameMap.board[checkRow][checkCol] == 'black')):
                self.mapRow = oldRow
                self.mapCol = oldCol
        
    def shoot(self,app,key):
        if (key == 'f') and (self.bulletsRemaining > 0):
            bullet = Bullet(app, self.mapRow, self.mapCol, app.mouseX, app.mouseY)
            app.activePlayerBullets.append(bullet)
            self.bulletsRemaining -= 1

class BossMap:
    def __init__(self,app):
        self.rows = 25
        self.cols = 25
        self.boardLeft = 0
        self.boardTop = 0
        self.boardWidth = app.width
        self.boardHeight = app.height
        self.board = [([None] * self.cols) for row in range(self.rows)]
        self.viewportSize = 20
    
        self.generateWalls()
        #initialize cell dimensions to parse through 
        self.cellWidth = self.boardWidth / self.cols
        self.cellHeight = self.boardHeight / self.rows
        
        self.fillColor = 'white'
        self.borderColor = 'black'
        self.cellBorderWidth = 0.2
        
        # store all positions initially to draw in one pass
        self.cellPositions = []
        for row in range(self.rows):
            rowPositions = []
            for col in range(self.cols):
                cellLeft = self.boardLeft + col * self.cellWidth
                cellTop = self.boardTop + row * self.cellHeight
                rowPositions.append((cellLeft, cellTop))
            self.cellPositions.append(rowPositions)

        self.rooms = []
        self.rooms.append(Room(1,1,self.cols-2,self.rows-2))
        self.createWallImage()
    
    def createWallImage(self): #draw background
        # https://lesterbanks.com/2018/02/working-hexels-drawing-tiled-pixel-art/
        rawImage = CMUImage(Image.open('floor image.png'))
        # Make image same size as map
        targetSize = (500, 500)  # app width/height
        resized = rawImage.image.resize(targetSize)
        self.floorImage = CMUImage(resized)

        
    def generateWalls(self):
        #make sure outer walls are black
        for row in range(self.rows):
            for col in range(self.cols):
                if (row == 0) or (row == self.rows-1) or (col == 0) or (col == self.cols-1): 
                    self.board[row][col] = 'black'
    
    # draw all board cells
    def drawBoard(self,app):
        # https://lesterbanks.com/2018/02/working-hexels-drawing-tiled-pixel-art/
        drawImage(self.floorImage,0,0)

        for row in range(self.rows):
            for col in range(self.cols):    
                cellLeft, cellTop = self.cellPositions[row][col]
                if self.board[row][col] == 'black':
                    drawRect(cellLeft,cellTop,self.cellWidth, self.cellHeight, 
                             fill='black', border='black', borderWidth=2)
    
    def getScreenCoords(self,app,mapRow,mapCol,isPlayer=False):
        screenX = mapCol * self.cellWidth
        screenY = mapRow * self.cellHeight
        return (screenX, screenY)
                    
class Map:
    def __init__(self,app):
        self.rows = 80
        self.cols = 80
        self.boardLeft = 0
        self.boardTop = 0
        
        # initialize player and camera positions
        self.mapRow = 25
        self.mapCol = 25
        self.viewportSize = 20

        # initialize cell dimensions to parse through 
        self.boardWidth = app.width
        self.boardHeight = app.height
        self.cellWidth = self.boardWidth / self.viewportSize
        self.cellHeight = self.boardHeight / self.viewportSize
        
        # visual properties of cells
        self.fillColor = 'white'
        self.borderColor = 'black'
        self.cellBorderWidth = 0.2
        
        # initialize each room and connection property
        self.minRoomSize = 14
        self.maxRoomSize = 25
        self.numRooms = 30
        self.corridorWidth = 4
        self.roomCenterGridCoords = []

        # initialize entire board (to be carved out for rooms)
        self.board = [(['black'] * self.cols) for row in range(self.rows)]
        self.rooms = []
        
        # store seen floor positions so we don't need to keep redrawing floor
        self.lastStartRow = None
        self.lastStartCol = None
        self.lastEndRow = None
        self.lastEndCol = None

        # randomly generate map based on difficulty
        # -> creates rooms, corridors connecting rooms, final boss area
        self.generateMap()
        app.map = self # stores map as it is being created -> allows for seamless
                       # room generation -> help from chatGPT
        self.initializeRoomFloors(app)

    # initilaize picture for room floor
    def initializeRoomFloors(self,app):
        for room in self.rooms:
            room.scaleFloorImage(app)
    
    # image for background
    # https://lesterbanks.com/2018/02/working-hexels-drawing-tiled-pixel-art/
    def drawVisibleRoomFloors(self,app,centerRow,centerCol):

        # calculate the visible area on screen
        startRow = max(0, int(centerRow - self.viewportSize/2))
        startCol = max(0, int(centerCol - self.viewportSize/2))
        endRow = min(self.rows, startRow + self.viewportSize)
        endCol = min(self.cols, startCol + self.viewportSize)

        # draw floors for visible rooms only
        for room in self.rooms:
            # check if room is visible in viewport
            if ((room.x + room.width  >= startCol)  and (room.x <= endCol)  and 
                (room.y + room.height >= startRow)  and (room.y <= endRow)):
                room.drawFloorImage(app, startRow, startCol)

    def generateMap(self):
        self.generateRooms()
        self.generateCorridors()
        
    def generateCorridors(self):
        # connect every room to the next room to create a manueverable map
        for roomIndex in range(len(self.rooms)-1):
            self.createCorridor(self.rooms[roomIndex], self.rooms[roomIndex+1])

    def generateCorridors(self):
        # connect every room to the next room to create a maneuverable map
        failedConnections = []
        for roomIndex in range(len(self.rooms)-1):
            room1 = self.rooms[roomIndex]
            room2 = self.rooms[roomIndex+1]

            corridorCreated = False
            attempt = 0
            maxAttempts = 4

            # try to create corridors between rooms, if it fails try again
            # until timed out           
            while (not corridorCreated) and attempt < maxAttempts: 
                corridorCreated = self.createCorridor(room1,room2)
                # if a corridor is successfuly created, exit
                attempt += 1
            
            if attempt >= maxAttempts:
                failedConnections.append((room1, room2))

        # try failed connections the other way    
        for (room1, room2) in failedConnections:
            self.createCorridor(room2, room1)

    def createCorridor(self,room1,room2):
        x1,y1 = room1.getCenter()
        x2,y2 = room2.getCenter()
        
        # 50/50 chance to get horizontal or vertical connection    
        # allows more randomized connections and random map generation!
        direction = random.choice(['vertical','horizontal'])
    
        # create horizontal first
        if direction == 'horizontal':
            self.createHorizontalCorridor(x1,x2,y1)
            self.createVerticalCorridor(y1,y2,x1)
            
        # create vertical first
        elif direction == 'vertical':
            self.createVerticalCorridor(y1,y2,x1)
            self.createHorizontalCorridor(x1,x2,y1)
    
    def createHorizontalCorridor(self,x1,x2,y):
        # loop through each column of the corridor, adjust cells accordingly
        for x in range(min(x1,x2), max(x1,x2)): 
            for w in range(self.corridorWidth):
                # verify corridor is still inside map
                if (0 <= y + w < self.rows) and (0 <= x < self.cols):
                    if not self.isRoom(y+w,x): # verify it is not covering a room
                        self.board[y+w][x] = 'darkRed'
    
    def createVerticalCorridor(self,y1,y2,x):
        # loop through each column of the corridor, adjust cells accordingly
        for y in range(min(y1,y2), max(y1,y2)): 
            for w in range(self.corridorWidth):
                # verify corridor is still inside map
                if (0 <= y < self.rows) and (0 <= x + w < self.cols):
                    if not self.isRoom(y,x+w): # verify it is not covering a room
                        self.board[y][x+w] = 'darkRed'
    
    
    def isRoom(self,row,col):
        # make sure the corridors are not covering any rooms
        return (self.board[row][col] is None)
    
    def generateRooms(self):
        attemptsToGenerate = 0
        maxAttempts = 100
        # maximum attempts so it does not time out 
        # sometimes it will be stuck in an infinite loop trying to generate as 
        # many rooms as possible because of a bad initial spot
        
        while (len(self.rooms) < self.numRooms) and (attemptsToGenerate < maxAttempts):
            # generate until we reach desired num of rooms or timeout
            room = self.generateRandomRoom()
            
            #check if there is space to place room on map
            if self.isValidRoomLocation(room):
                self.carveRoom(room)
                self.rooms.append(room)
            attemptsToGenerate += 1

    def generateRandomRoom(self):
        # generate randomly sized room, place it in random location
        size = random.randint(self.minRoomSize, self.maxRoomSize)
        height = random.randint(self.minRoomSize, self.maxRoomSize)
        x = random.randint(1, self.cols - size - 1)
        y = random.randint(1, self.rows - size - 1)
        
        # square room to increase efficiency of drawing textures
        room = Room(x,y,size,size)

        # store info for mob generation
        gridX,gridY = room.getCenter()
        self.roomCenterGridCoords.append((gridX,gridY))
        
        return Room(x,y,size,size)
    
    def isValidRoomLocation(self,room):
        # make sure room is not overlapping another rom
        for existingRoom in self.rooms:
            if room.overlaps(existingRoom):
                return False
        return True

    def carveRoom(self,room):
        # carve out the None's in the list to create the room
        x1,y1,x2,y2 = room.getBounds()
        for row in range(y1, y2):
            for col in range(x1, x2):
                self.board[row][col] = None
    
    # drawBoard and drawCell is derived from the Tetris project in CS academy 
    # and heavily modified to fit this paradigm of map generation!
    # -> uses similar logic of tracking and drawing cells

    # draw all board cells
    def drawBoard(self,app):
        self.drawViewport(app)
        app.player1.draw(app)

    def drawViewport(self,app):
        # calculate player camera boundaries to center the player
        # calculating coordinate/grid system positions were made with 
        # the help of chatGPT -> December 3, 2024

        # find topleft corner of viewport
        startRow = max(0, int(app.player1.mapRow - self.viewportSize / 2))
        startCol = max(0, int(app.player1.mapCol - self.viewportSize / 2))

        # ensure we are not past map boundaries!!
        endRow = min(self.rows, startRow + self.viewportSize)
        endCol = min(self.cols, startCol + self.viewportSize)

        centerRow, centerCol = app.player1.mapRow, app.player1.mapCol
        self.drawVisibleRoomFloors(app,centerRow,centerCol)

        #screen position of player
        screenX, screenY = app.width/2, app.height/2

        # character cannot be centered if we are near the edge -> not enough space
        if (endRow - startRow) < self.viewportSize:
            startRow = max(0, endRow - self.viewportSize)
        if (endCol - startCol) < self.viewportSize:
            startCol = max(0, endCol - self.viewportSize)

        # MUST ALLOW FREEFORM ALONG EDGES
        # -> allows us to access entire room, even if whole room + viewport
        #    cannot be rendered
        screenX, screenY = app.width/2, app.height/2

        # store previous offsets so bullets/mobs dont change with player
        self.baseOffsetX = app.width / 2 - app.player1.mapCol * self.cellWidth
        self.baseOffsetY = app.height / 2 - app.player1.mapRow * self.cellHeight

        # make sure edge adjustments only affect player
        if app.player1.mapCol < self.viewportSize/2: # if too far left
            screenX = app.player1.mapCol * self.cellWidth
        elif app.player1.mapCol > self.cols - self.viewportSize/2: # if too far right
            screenX = app.width/2 + ((app.player1.mapCol - (self.cols - self.viewportSize/2)) 
                                        * self.cellWidth)

        if app.player1.mapRow < self.viewportSize/2: # if too far up
            screenY = app.player1.mapRow * self.cellHeight
        elif app.player1.mapRow > self.rows - self.viewportSize/2:  # near bottom
            screenY = app.height/2 + ((app.player1.mapRow - (self.rows - self.viewportSize/2)) 
                                        * self.cellHeight)
        # apply changes, if any to the player only
        app.player1.x = screenX
        app.player1.y = screenY

        self.offsetX = self.baseOffsetX
        self.offsetY = self.baseOffsetY

        # only draw cells visible in the viewport
        for viewRow in range(startRow, endRow):
            for viewCol in range(startCol,endCol):
                screenRow = viewRow - startRow
                screenCol = viewCol - startCol
                cellLeft = screenCol * self.cellWidth
                cellTop = screenRow * self.cellHeight
                cellColor = self.board[viewRow][viewCol]
                if cellColor != None:
                    self.drawCell(app, viewRow, viewCol, cellColor,
                              cellLeft, cellTop, self.cellWidth, self.cellHeight)


    def mapToScreen(self,mapX,mapY, isPlayer=False):
        # input map coordinates, return screen coordinates
        if isPlayer:
            return (self.player1.x, self.player1.y)
        else: # for mobs, bullets, all other objects
            screenX = mapX * self.cellWidth + self.baseOffsetX
            screenY = mapY * self.cellHeight + self.baseOffsetY
            return (screenX, screenY)

    def checkFreeform(self,app):
        # check if we're in freeform mode
        # freeform is when we are near the edges of the map and the player is 
        # no longer centered to account for map boundaries and space for camera view
        nearLeftEdge = app.player1.mapCol < app.map.viewportSize/2
        nearRightEdge = app.player1.mapCol > app.map.cols - app.map.viewportSize/2
        nearTopEdge = app.player1.mapRow < app.map.viewportSize/2
        nearBottomEdge = app.player1.mapRow > app.map.rows - app.map.viewportSize/2
        
        # Adjust mouse coordinates based on viewport mode
        if nearLeftEdge or nearRightEdge or nearTopEdge or nearBottomEdge:
            return True
        return False

    def getScreenCoords(self, app, mapRow, mapCol, isPlayer=False):
        # debugged with the help of chatGPT -> December 5th, 2024
        # calculate base screen position
        screenX = app.width/2
        screenY = app.height/2
        
        # check if we're near edges (in freeform mode)
        nearLeftEdge = app.player1.mapCol < self.viewportSize/2
        nearRightEdge = app.player1.mapCol > self.cols - self.viewportSize/2
        nearTopEdge = app.player1.mapRow < self.viewportSize/2
        nearBottomEdge = app.player1.mapRow > self.rows - self.viewportSize/2
        
        # adjust coords based on viewport/freeform mode -> edges and camera pos
        if isPlayer:
            if nearLeftEdge:
                screenX = app.player1.mapCol * self.cellWidth
            elif nearRightEdge:
                screenX = app.width/2 + ((app.player1.mapCol - (self.cols - self.viewportSize/2)) 
                                        * self.cellWidth)
            if nearTopEdge:
                screenY = app.player1.mapRow * self.cellHeight
            elif nearBottomEdge:
                screenY = app.height/2 + ((app.player1.mapRow - (self.rows - self.viewportSize/2)) 
                                        * self.cellHeight)
            return screenX, screenY
        else:
            # store coords for all other objects to account for player shift in freeform
            if nearLeftEdge:
                screenX = mapCol * self.cellWidth
            elif nearRightEdge:
                screenX = app.width/2 + ((mapCol - (self.cols - self.viewportSize/2)) 
                                        * self.cellWidth)
            else:
                screenX = mapCol * self.cellWidth + self.baseOffsetX
                
            if nearTopEdge:
                screenY = mapRow * self.cellHeight
            elif nearBottomEdge:
                screenY = app.height/2 + ((mapRow - (self.rows - self.viewportSize/2)) 
                                        * self.cellHeight)
            else:
                screenY = mapRow * self.cellHeight + self.baseOffsetY
                
            return screenX, screenY

    # go cell by cell to assign color to each cell
    def drawCell(self,app,row,col,color, cellLeft, cellTop, cellWidth, cellHeight):
        if color != 'white':
            
            drawRect(cellLeft, cellTop, cellWidth, cellHeight, fill=color)
                
class Room:
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.bufferZone = 3
        self.size = max(width,height)
        self.width = self.height = self.size #rooms are square so image can scale
        # floor image found on https://pixeljoint.com/forum/forum_posts.asp?TID=26658
        self.floorImage = 'floor image.png'

    def scaleFloorImage(self,app):
        # try/except imported from chatGPT to make sure we are drawing after initialized
        # used in conjunction with app.map = self
        # try to draw, if map isnt initialized yet then visit later
        try: 
            rawImage = CMUImage(Image.open('floor image.png'))
            targetSize = int(self.size * app.map.cellWidth)
            
            # resize image using PIL to room size to only draw 1 background
            resized = rawImage.image.resize((targetSize, targetSize))
            self.floorImage = CMUImage(resized)

        # will draw once map is initialized
        except (AttributeError, Exception) as e:
            print(f"Error in scaleFloorImage: {str(e)}")
            pass

    def drawFloorImage(self, app, startRow, startCol):
        # convert room position to screen coordinates
        screenX = (self.x - startCol) * app.map.cellWidth
        screenY = (self.y - startRow) * app.map.cellWidth

        # if we are on a room, draw floor
        if self.floorImage is None:
            self.scaleFloorImage(app)
        drawImage(self.floorImage, screenX, screenY)
        
    def getCenter(self):
        centerX = self.x + self.width//2
        centerY = self.y + self.height//2
        return (centerX, centerY)

    def overlaps(self, otherRoom):
        # make sure that current room is not overlapping with another room
        # bufferZone makes sure that there is a gap between rooms 
        return not (
               (self.width + self.x + self.bufferZone < otherRoom.x) or
               (self.x > otherRoom.x + otherRoom.width + self.bufferZone) or 
               (self.y + self.height + self.bufferZone < otherRoom.y) or 
               (self.y > otherRoom.y + otherRoom.height + self.bufferZone)
                                                                ) # BOOLEAN
    
    def getBounds(self): # return room properties
        return (self.x, self.y, self.x+self.width, self.y+self.height)

class Button: # interactive UI 
    def __init__(self,app,x,y,width,height,label='',color='black', outlineColor='black',
                 borderWidth=2,textSize=24, hoverColor='grey', hoverWidth=3):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.label = label
        self.color = color
        self.outlineColor = outlineColor
        self.borderWidth = borderWidth
        self.textSize = textSize
        self.hoverColor = hoverColor
        self.hoverWidth = hoverWidth
        self.font = 'Montserrat'
        
    def mouseInButton(self,mouseX,mouseY):
        return ((self.x - self.width/2 <= mouseX <= self.x + self.width/2) and
                (self.y - self.height/2 <= mouseY <= self.y + self.height/2))
    
    def draw(self,app):
        #rect shape
        drawRect(self.x, self.y, self.width, self.height, fill=self.color, 
                 align='center')
        #outline
        drawRect(self.x,self.y,self.width,self.height,fill=None,
                 border=self.outlineColor,borderWidth = self.borderWidth,
                 align='center')
        
        # selection rect
        if self.mouseInButton(app.mouseX, app.mouseY):
            drawRect(self.x,self.y,self.width+20,self.height+20,fill=None,
                 border=self.hoverColor,borderWidth=self.hoverWidth,align='center')
        
        #label with text
        drawLabel(self.label,self.x,self.y,size=self.textSize,bold=True,font=self.font)

class Bullet:
    def __init__(self, app, playerMapRow, playerMapCol, mouseX, mouseY):
        # find starting position of the bullet
        self.mapRow = playerMapRow
        self.mapCol = playerMapCol
        
        # determine mouse direction for bullet travel
        dx = mouseX - app.player1.x
        dy = mouseY - app.player1.y
        
        # calculate length to make sure we do not divide by 0 
        # (if mouse is directly on top of player do nothing)
        length = (dx**2 + dy**2)**0.5
        
        if length > 0:
            # convert screen direction to map direction since bullet moves in map coords
            self.dx = (dx/length) * (1/app.map.cellWidth)
            self.dy = (dy/length) * (1/app.map.cellHeight)
        else:
            self.dx = self.dy = 0
            
        self.radius = 5
        self.speed = 4
        self.color = 'red'
        self.damage = 1
            
    def move(self,app):
        # move using map coordinates
        self.mapRow += self.dy * self.speed
        self.mapCol += self.dx * self.speed

    def draw(self, app):
        # convert map coordinates to screen coordinates for drawing
        screenX, screenY = app.map.getScreenCoords(app, self.mapRow, self.mapCol)
        drawCircle(screenX, screenY, self.radius, fill=self.color)
        
    def checkInBounds(self, app):
        # make sure bullet is not colliding with map edges
        gridRow, gridCol = int(self.mapRow), int(self.mapCol)
        if (gridRow < 0 or gridRow >= app.map.rows or 
            gridCol < 0 or gridCol >= app.map.cols):
            return False
        if app.map.board[gridRow][gridCol] == 'black':
            return False
        return True

def updateGameObjects(app):
    bulletsToRemove = set()
    mobsToRemove = set()

    for mob in app.activeMobs:
        handleMobMovement(app,mob)

    # update player and enemy bullets, remove if not valid or hit
    handleBullets(app,bulletsToRemove,mobsToRemove,True)
    handleBullets(app,bulletsToRemove,mobsToRemove,False)
    removeInstances(app,bulletsToRemove,mobsToRemove)

def handleMobMovement(app,mob):
    if mob.currMobHealth >= 1:
        if isinstance(mob, RangedMob):
            mob.update(app) # handle shooting and cooldown
        
        # store old position to make sure mob isnt crossing over walls
        oldRow, oldCol = mob.mapRow, mob.mapCol

        # move mobs based on player location "chase"
        mob.move(app)

        newRow, newCol = int(mob.mapRow), int(mob.mapCol)
        # if mob is out of bounds, undo movement
        if not mob.checkInBounds(app,newRow,newCol):
            mob.mapRow = oldRow
            mob.mapCol = oldCol
        
                # Update screen coordinates based on map type
        if isinstance(app.map, BossMap):
            mob.x = mob.mapCol * app.map.cellWidth
            mob.y = mob.mapRow * app.map.cellHeight
            mob.update(app)

        else:
            # update screen position using offset iin the base viewport
            mob.x, mob.y = app.map.getScreenCoords(app, mob.mapRow, mob.mapCol, 
                                                  isPlayer=False)

def removeInstances(app,bulletsToRemove,mobsToRemove):    
    # remove instances once unnecessary
    for bullet in bulletsToRemove:
        if bullet in app.activePlayerBullets:
            app.activePlayerBullets.remove(bullet)
        if bullet in app.activeEnemyBullets:
            app.activeEnemyBullets.remove(bullet)
    for mob in mobsToRemove:
        if mob in app.activeMobs:
            app.activeMobs.remove(mob)

def handleBullets(app,bulletsToRemove,mobsToRemove,isPlayerBullet=True):
    # initialize which bullets we are examining -> player's or mob's
    bulletList = app.activePlayerBullets if isPlayerBullet else app.activeEnemyBullets
    
    # remove bullet if it goes out of bounds
    for bullet in bulletList:
        bullet.move(app)
        if not bullet.checkInBounds(app):
            bulletsToRemove.add(bullet)
            continue

        bulletX, bulletY = app.map.getScreenCoords(app, bullet.mapRow, bullet.mapCol)

        if isPlayerBullet:
            for mob in app.activeMobs: # if bullet hits a mob
                if mob.currMobHealth <= 0:
                    continue

                mobX, mobY = app.map.getScreenCoords(app, mob.mapRow, mob.mapCol)

                # check if bullet hit mob
                inHitBox = ((mobX - mob.width/2 <= bulletX <= mobX + mob.width/2) and 
                            (mobY - mob.height/2 <= bulletY <= mobY + mob.height/2))

                if ( inHitBox or (bulletDistance(bulletX, bulletY, mobX, mobY) < 5) ): # bullet collision
                    bulletsToRemove.add(bullet)
                    mob.currMobHealth -= bullet.damage
                    mob.healthPercent = mob.currMobHealth/10

                    if mob.currMobHealth <= 0: # kill mob 
                        mobsToRemove.add(mob)
                        app.player1.enemiesKilled += 1
                    break
                
        elif not isPlayerBullet:
            playerX, playerY = app.map.getScreenCoords(app, app.player1.mapRow, app.player1.mapCol)
            # track if mob has hit player
            inHitBox = ((playerX <= bulletX <= playerX + app.player1.playerWidth) and
                        (playerY <= bulletY <= playerY + app.player1.playerHeight))

            if inHitBox or bulletDistance(bulletX, bulletY, playerX, playerY) < 5:
                bulletsToRemove.add(bullet)
                app.player1.health -= bullet.damage
                if app.player1.health <= 0:
                    app.gameOver = True

        
def bulletDistance(x1,y1,x2,y2):
    dx = x1 - x2
    dy = y1 - y2
    return (dx**2 + dy**2)**0.5
 


class Mob:
    def __init__(self,app):
        self.height = 30
        self.width = 30
        self.mobColor = 'purple'
        self.x = 0
        self.y = 0
        self.mapRow, self.mapCol = self.findSpawnZone(app)
        self.initialMobHealth = 10
        self.currMobHealth = 10
        self.speed = 0.15
        self.healthBarGap = 10
        self.healthBarX = self.x
        self.healthBarY = self.y
        self.healthPercent = 1
        self.healthBarHeight = 10

    def checkInBounds(self,app,newRow,newCol):
        if (not (0 < newRow < app.map.rows) or 
            not (0 < newCol < app.map.cols)):
            return False
        if (app.map.board[newRow][newCol] == 'black'):
            return False # tile is not hallway or room
        return True

    def findSpawnZone(self,app):
        # keep spawning until a valid spawnpoint is found
        while True:
            room = random.choice(app.map.rooms)
            centerX, centerY = room.getCenter()
            
            # randomly choose a room, randomly choose a spot in the room to spawn
            offSetX = random.randint(-3, 3)
            offSetY = random.randint(-3, 3)
            newCol = int(centerX + offSetX)
            newRow = int(centerY + offSetY)

            # make sure spawnpoint is:
            # -> in bounds, in a room, not in a corridor/blackspace, not in corner
            if ( (0 <= newRow < app.map.rows) and 
                 (0 <= newCol < app.map.cols) and 
                 (app.map.board[newRow][newCol] is None) and 
                 (app.map.board[newRow+1][newCol+1]) != 'black' and
                 (app.map.board[newRow-1][newCol-1] != 'black' )):
                return (float(newRow), float(newCol))
            

    def draw(self,app):
        if self.currMobHealth >= 1: # make sure mob is alive
            self.drawHealthBar()
            # https://www.angelexxa.com/2016/03/game-review-pixel-robot-jump-saga.html
            mobImage = CMUImage(Image.open('blue mob.png'))
            drawImage(mobImage, self.x, self.y, align='center')
    
    def drawHealthBar(self):
        self.healthBarX = self.x
        self.healthBarY = self.y - self.width/2 - self.healthBarGap
        drawRect(self.healthBarX, self.healthBarY, self.width+2, self.healthBarHeight+2, 
                 fill='white', border='black', borderWidth=2,align='center') # health outline
        healthPercent = (self.currMobHealth / self.initialMobHealth) * self.width
        drawRect(self.healthBarX - (self.width/2), self.healthBarY, 
             healthPercent, self.healthBarHeight, fill='red', align='left')

    def move(self,app):
        # track player and move mob closer to the player
        dx = app.player1.mapCol - self.mapCol
        dy = app.player1.mapRow - self.mapRow
        totalDistance = (dx**2 + dy**2)**0.5
        
        if totalDistance > 0:
            self.mapCol += (dx/totalDistance) * self.speed
            self.mapRow += (dy/totalDistance) * self.speed

class RangedMob(Mob):
    def __init__(self,app):
        super().__init__(app) # inherit methods
        self.mobColor = 'yellow'
        self.currMobHealth = 5
        self.initialMobHealth = 5
        self.shootCoolDown = 60
        self.currentCoolDown = 10
        self.projectileSpeed = 0.125
        self.projectileRadius = 4
        self.projectileColor = 'orange'
        self.damage = 5

    def draw(self,app):
        if self.currMobHealth >= 1: # make sure mob is alive
            self.drawHealthBar()
            # https://www.angelexxa.com/2016/03/game-review-pixel-robot-jump-saga.html
            mobImage = CMUImage(Image.open('green mob.png'))
            drawImage(mobImage, self.x, self.y, align='center')

    def shoot(self,app):
        if (self.currentCoolDown <= 0) and (self.currMobHealth > 0):
            #keep track of player and bullet placement
            dx = app.player1.mapCol - self.mapCol
            dy = app.player1.mapRow - self.mapRow
            distance = (dx**2 + dy**2) ** 0.5
            
            if distance > 0:
                dx = (dx/distance) 
                dy = (dy/distance) 
            bullet = EnemyBullet(self.mapRow, self.mapCol, dx, dy, self.projectileColor, 
                                 self.projectileRadius,self.damage)
            app.activeEnemyBullets.append(bullet)
            
            self.currentCoolDown = self.shootCoolDown
    
    def update(self,app):
        if self.currentCoolDown > 0:
            self.currentCoolDown -= 1
        
        # only shoot if player is within range
        dx = app.player1.mapCol - self.mapCol
        dy = app.player1.mapRow - self.mapRow
        distance = (dx**2 + dy**2) ** 0.5
        if distance < 8: 
            self.shoot(app)

class Boss(Mob): # boss fight!

    # boss fight has multiple phases
    # -> each phase occurs throughout different stages of health
    # -> 100-30% health: attacks in all directions
    # -> <30% health: bullets bounce and mobs spawn
    def __init__(self,app):
        super().__init__(app)
        self.color = 'orange'
        self.mobHeight = 60
        self.mobWidth = 60
        self.currMobHealth = 50
        self.initialHealth = 50
        self.phase = 1
        self.normalSpeed = 0.1
        self.dashSpeed = 1
        self.speed = self.normalSpeed # only change speed when dash is initialized
        
        # move boss to top center of room
        self.mapRow = float(app.map.rows/4)  # 1/4 down from top
        self.mapCol = float(app.map.cols/2)  # Center horizontally
        self.x, self.y = app.map.getScreenCoords(app, self.mapRow, self.mapCol)

        # bullet speeds and cooldowns
        self.speedX = 3
        self.speedY = 3
        self.attackCooldown = 120
        self.currentCooldown = 60 #happen every 2 seconds
        self.projectileSpeed = 0.025
        self.projectileRadius = 5
        self.projectileColor = 'red'
        self.projectileNumber = 8
        self.phase2BulletCount = 4

        # incremenets used for phase 1 attacks
        self.currentAngle = 0
        self.angleIncrement = math.pi / self.projectileNumber
        self.spiralAngle = 0
        self.currentDashCooldown = 0


    def draw(self,app):
        if self.currMobHealth >= 1: # make sure mob is alive
            self.drawHealthBar()
            # https://www.angelexxa.com/2016/03/game-review-pixel-robot-jump-saga.html
            rawImage = Image.open('red mob.png')
            # resize the image to match mob's width and height
            resized = rawImage.resize((self.width, self.height))
            mobImage = CMUImage(resized)
            drawImage(mobImage, self.x, self.y, align='center')

    def update(self,app):
        if self.currMobHealth <= 0:
            return
        self.updatePhaseAndAttacks(app)
        self.move(app)

        # recharge attacks after cooldown
        if self.currentCooldown > 0:
            self.currentCooldown -= 1

        if (self.phase == 1) and (self.currentCooldown <= 0):
            self.phaseOneAttacks(app)
            self.currentCooldown = self.attackCooldown

    def updatePhaseAndAttacks(self,app):
        healthPercentage = (self.currMobHealth / self.initialMobHealth) * 100
        # constantly check if mob health has changed to initiate phase change
        if 30 <= healthPercentage <= 99:
            self.phase = 1  
        if 0 < healthPercentage < 30:
            self.phase = 2

        # handle and adjust cooldowns
        if self.currentCooldown > 0:
            self.currentCooldown -= 1
        elif self.currentDashCooldown > 0:
            self.currentDashCooldown -= 1

        # handle attacks once cooldowns are reached
        if self.currentCooldown > 0:
            self.currentCooldown -= 1
        elif self.currentCooldown <= 0:
            if self.phase == 1:
                self.phaseOneAttacks(app)
            elif self.phase == 2:
                self.phaseTwoAttacks(app)
            self.currentCooldown = self.attackCooldown


    def phaseOneAttacks(self, app):
        # angle calculations made using chatGPT
        numBullets = 8
        angleStep = (2 * math.pi) / numBullets
        
        for i in range(numBullets):
            angle = i * angleStep
            dx = math.cos(angle)
            dy = math.sin(angle)
            
            bullet = EnemyBullet(self.mapRow, self.mapCol, dx, dy, 
                            'red', self.projectileRadius, 10)
            app.activeEnemyBullets.append(bullet)
        
        self.currentAngle += math.pi / 8
    
    def phaseTwoAttacks(self,app):
        # angle calculations made using chatGPT
        for _ in range(self.phase2BulletCount):
            angle = random.uniform(0, 2 * math.pi)
            dx = math.cos(angle)
            dy = math.sin(angle)
            
            bullet = EnemyBullet(self.mapRow, self.mapCol, dx, dy, 
                            'blue', self.projectileRadius, 15)
            bullet.bounce = True
            app.activeEnemyBullets.append(bullet)
                    
class EnemyBullet: #keep track of bullet coming from
    def __init__(self,mapRow,mapCol,dx,dy,color,radius, damage=0):
        self.mapRow = mapRow
        self.mapCol = mapCol
        self.dx = dx
        self.dy = dy
        self.color = color
        self.radius = radius
        self.speed = .05
        self.damage = damage
                
        # Movement control
        self.movementCooldown = 120  # frames between movements
        self.currentMovementCooldown = 0
        self.isMoving = False
        self.moveTime = 30  # how long boss moves for
        self.currentMoveTime = 0
        self.targetRow = self.mapRow
        self.targetCol = self.mapCol
        self.bounce = False

    def move(self,app):
        
        # Move in current direction
        self.mapRow += self.dy
        self.mapCol += self.dx
        
        # bounce off walls
        if self.bounce and isinstance(app.map, BossMap):
            if self.mapRow < 2 or self.mapRow > app.map.rows-2:
                self.dy = -self.dy
            if self.mapCol < 2 or self.mapCol > app.map.cols-2:
                self.dx = -self.dx

    def draw(self,app):
        screenX, screenY = app.map.getScreenCoords(app, self.mapRow, self.mapCol)
        drawCircle(screenX, screenY, self.radius, fill=self.color, align='center')
    
    def checkInBounds(self,app):
        gridRow, gridCol = int(self.mapRow), int(self.mapCol)

        # bounds differ based on type of map
        if isinstance(app.map, BossMap):
            if ((gridRow <= 2) or (gridRow >= app.map.rows-2) or 
                (gridCol <= 2) or (gridCol >= app.map.cols-2)):
                return False
            return True
        
        else: 
            if ( (gridRow < 0) or (gridRow >= app.map.rows) or 
                (gridCol < 0) or (gridCol >= app.map.cols) ):
                return False
            if app.map.board[gridRow][gridCol] == 'black':
                return False
            return True
        
class Stage:
    def __init__(self,app,stageNumber):
        # on every stage, generate new map and new number of mobs based on 
        # difficulty and stage level
        self.difficulty = app.difficulty
        self.totalStages = 3
        self.stageNumber = stageNumber
        self.completedStage = False
        self.initialSpawn = False
        self.stageCooldown = 240 # 4 seconds between stages
        self.currentCooldown = 0
        self.showCompletionScreen = False

    def spawnEnemies(self,app):
        app.activeMobs.clear()

        if self.stageNumber == 4: # boss stage
            app.map = BossMap(app)
            boss = Boss(app)
            
            app.activeMobs.append(boss)
            app.initialEnemyCount = 1
            app.remainingEnemyCount = 1
            
            # spawn player towards the center
            app.player1.x = app.width/2
            app.player1.y = app.height/2
            app.player1.mapRow = app.map.rows / 2
            app.player1.mapCol = app.map.cols / 2
            return

        # randomly spawn a number of mobs based on the difficulty
        if app.difficulty == 'EASY':
            mobCount = random.randint(3,5)
            rangedCount = random.randint(1,3)
        elif app.difficulty == 'MEDIUM':
            mobCount = random.randint(4,8)
            rangedCount = random.randint(3,5)
        elif app.difficulty == 'HARD':
            mobCount = random.randint(1,4)
            rangedCount = random.randint(8,12)
        
        # as stages progress, make sure each stage always scales and gets harder
        mobCount += self.stageNumber
        rangedCount += self.stageNumber // 2

        for _ in range(mobCount):
            app.activeMobs.append(Mob(app))
        
        for _ in range(rangedCount):
            app.activeMobs.append(RangedMob(app))
        
        app.initialEnemyCount = len(app.activeMobs)
        app.remainingEnemyCount = app.initialEnemyCount

    def drawStageComplete(self,app):
        if self.showCompletionScreen and (app.currentStage < 4):

            drawRect(app.width/2,app.height/2,app.width,75,fill='seaGreen',opacity=75, align='center')
            drawRect(app.width/2, app.height/2, 300, 100, fill='darkGreen', align='center')
            drawLabel(f'Stage {self.stageNumber} Complete!', app.width/2, app.height/2 - 20,
                        font='montserrant', fill='white', size = 25, bold=True)
            drawLabel(f'{self.totalStages - self.stageNumber} stages until the boss fight',
                        app.width/2, app.height/2 + 20,font='montserrant',size = 20,
                        fill='white')

        elif self.showCompletionScreen and app.currentStage == 4:
            drawRect(app.width/2,app.height/2,app.width,75,fill='seaGreen',opacity=75, align='center')
            drawRect(app.width/2, app.height/2, 475, 100, fill='darkGreen', align='center')
            drawLabel(f'Congratulations! Stages Complete!', app.width/2, app.height/2 - 20,
                        font='montserrant', fill='white', size = 25, bold=True)
            drawLabel(f'{app.player1.enemiesKilled} enemies killed!',
                        app.width/2, app.height/2 + 20,font='montserrant',size = 20,
                        fill='white')


    def drawGameOver(self,app):
            drawRect(app.width/2,app.height/2,app.width,75,fill='lightCoral',opacity=75, align='center')
            drawRect(app.width/2, app.height/2, 300, 100, fill='crimson', align='center')
            drawLabel(f'Game Over!', app.width/2, app.height/2 - 20,
                        font='montserrant', fill='white', size = 25, bold=True)
            drawLabel(f'{app.player1.enemiesKilled} enemies killed!', app.width/2, app.height/2 + 20,
                      font='montserrant',size = 20, fill='white')

    def update(self,app):
        if self.initialSpawn:
            self.spawnEnemies(app)
            self.initialSpawn = False
        
        # update stage completion and mob count
        app.remainingEnemyCount = len(app.activeMobs)
        if app.remainingEnemyCount == 0 and not self.completedStage:
            self.completedStage = True
            self.showCompletionScreen = True

        if self.showCompletionScreen: # show completion screen for 4 seconds
            self.currentCooldown += 1
            if self.currentCooldown >= self.stageCooldown: # move onto next stage
                self.showCompletionScreen = False
                self.currentCooldown = 0
                advanceToNextStage(app)
        
    def checkCompletedStage(self,activeMobs):
        if len(app.activeMobs) == 0: 
            print('stage complete!')
            self.completedStage = True
            return True
        return False

def drawScoreLabels(app):     
    # draw ammo bar
    ammoPercent = 175 * (app.player1.bulletsRemaining / app.player1.bulletsInitial)
    drawRect(50, 35, 175, 35, fill='white', border='black', borderWidth=2, align='left')

    if ammoPercent > 0: 
        drawRect(50, 35, ammoPercent, 35, fill='orange', align='left')
        drawLabel(f'AMMO: {app.player1.bulletsRemaining}', 137.5, 35, size=16, font='montserrat')
    else:
        drawLabel(f'OUT OF AMMO', 137.5, 35, size=16, font='montserrat')
    drawRect(50, 35, 175, 35, fill=None, border='black', borderWidth=2, align='left')
    
    # draw remaining enemy count for the stage
    drawRect(275, 35, 175, 35, fill='white', border='black', borderWidth=2, align='left')
    if app.remainingEnemyCount > 0:
        enemyPercent = 175 * (app.remainingEnemyCount / app.initialEnemyCount)
        drawRect(275, 35, enemyPercent, 35, fill='green', align='left')
        drawRect(275, 35, 175, 35, fill=None, border='black', borderWidth=2, align='left')
        drawLabel(f'Enemies Alive: {app.remainingEnemyCount}', 362.5, 35, size=16, font='montserrat')

    # draw player healthbar
    drawRect(app.width/2,450,175,35,fill='white',border='black',borderWidth=2,align='center')
    if app.player1.health >= 1:
        healthPercent = 175 * (app.player1.health / app.player1.initialHealth)
        drawRect(app.width/2 - 87.5, 450, healthPercent, 35, fill='red', align='left')
        drawRect(app.width/2,450,175,35, fill=None, border='black', borderWidth=2, align='center')
        drawLabel(f'HEALTH: {app.player1.health}', app.width/2,450, size=16, font='montserrat',align='center')

    app.stage.drawStageComplete(app)

def drawGameProperties(app): 
    for bullet in app.activePlayerBullets:
        bullet.draw(app)

    for mob in app.activeMobs:
        mob.draw(app)
    # for powerup in app.powerups:
    #     powerup.draw()
    
    for bullet in app.activeEnemyBullets:
        bullet.draw(app)

def resetGame(app):
    pass

def drawTitleScreen(app):
    
    menuImage = 'menu background.png'
    # https://www.reddit.com/user/Ginmaru_PixelArt/
    menuImageDisplay = CMUImage(Image.open(menuImage))
    drawImage(menuImageDisplay,0,0)
    drawRect(app.width/2, 100, 450, 100, fill='darkRed', border='grey', align='center')
    drawLabel('DUNGEON FIGHTER 112', app.width/2, 100, fill='white', font='montserrant',size=32) 
    app.playButton.draw(app)
    app.easyDifficultyButton.draw(app)
    app.medDifficultyButton.draw(app)
    app.hardDifficultyButton.draw(app)
    
    if app.difficulty != None:
        drawLabel(f'Current difficulty: {app.difficulty}',app.width/2,420,size=20,
            font='Montserrat',fill='white',bold=True)
    else:
        drawLabel(f'Select a difficulty level to start!',app.width/2,420,size=20,
            font='Montserrat',fill='white',bold=True)


def redrawAll(app):
    app.map.drawBoard(app)
    if app.gameState == 'titleScreen':
        drawTitleScreen(app)

    elif app.gameState == 'playing' or app.gameState == 'gameOver':
        if app.ongoingGame: 
            app.map.drawBoard(app)
            app.player1.draw(app)
            drawScoreLabels(app)
            drawGameProperties(app)
            if app.gameState == 'gameOver':
                app.stage.drawGameOver(app)

def advanceToNextStage(app):
    app.currentStage += 1

    # reset properties
    app.activeMobs.clear()
    app.activePlayerBullets.clear()
    app.activeEnemyBullets.clear()

    if app.currentStage <= app.maxStages:
        app.map = Map(app) # generate new map every stage

        # make sure player is spawned in valid room
        spawnRoom = random.choice(app.map.rooms) 
        centerX,centerY = spawnRoom.getCenter()
        while app.map.board[int(centerY)][int(centerX)] != None:
            spawnRoom = random.choice(app.map.rooms)
            centerX, centerY = spawnRoom.getCenter()
        
        # set player position
        app.player1.mapCol = float(centerX)
        app.player1.mapRow = float(centerY)
        app.stage = Stage(app,app.currentStage) # reset the stage properties
        app.stage.initialSpawn = True
        app.stage.spawnEnemies(app) # spawn enemies

        # give player bonuses as stage is finished
        app.player1.bulletsRemaining = 200
        app.player1.health = min(100,app.player1.health+30)

    else: # game is finished, player won!
        app.gameState = 'winner'


def onAppStart(app):
    app.remainingEnemyCount = 3
    app.initialEnemyCount = 10
    app.currentStage = 1
    app.maxStages = 4
    app.difficulty = None
    
    app.stepsPerSecond = 60
    app.width = 500
    app.height =  500
    app.gameState = 'titleScreen'
    app.ongoingGame = True
    app.gameOver = False
    
    app.playButton = Button(app,app.width/2, app.height/2, 120,65,'PLAY',rgb(110, 56, 52),
                            rgb(5,2,1),3,28)
    app.easyDifficultyButton = Button(app,app.width/2 - 150, app.height/2 + 100, 135, 60,
                                      'EASY', rgb(104, 178, 146),'darkGreen',3,24)
    app.medDifficultyButton = Button(app,app.width/2, app.height/2 + 100, 135, 60,
                                      'MEDIUM', rgb(172, 178, 104),'orange',3,24)
    app.hardDifficultyButton = Button(app,app.width/2 + 150, app.height/2 + 100, 135, 60,
                                      'HARD', rgb(178, 104, 136),'darkRed',3,24)

    
    app.movementKeys = {'w','a','s','d'}
    app.mouseX = app.width/2
    app.mouseY = app.width/2
    app.keysHeld = set()
    app.activePlayerBullets = list()
    app.activeEnemyBullets = list()
    app.activeMobs = list()

    app.maxMobs = 15
    app.mobsSpawned = False

    app.map = Map(app)
    
    app.stage = Stage(app,app.currentStage)
    app.player1 = Player(app)

def onKeyPress(app,key):
    if app.gameState == 'playing':
        app.player1.shoot(app,key)
        if key in app.movementKeys:
            app.keysHeld.add(key)
        

def onKeyRelease(app,key):
    if app.gameState == 'playing':
        if key in app.movementKeys:
            app.keysHeld.discard(key) # https://www.w3schools.com/python/ref_set_discard.asp 
                                      # discard makes sure code doesnt crash! 

def onMousePress(app,mouseX,mouseY):
    if app.gameState == 'titleScreen':
        if app.easyDifficultyButton.mouseInButton(mouseX,mouseY):
            app.difficulty = 'EASY'
            print(f'Difficulty Changed to: {app.difficulty}')
        if app.medDifficultyButton.mouseInButton(mouseX, mouseY):
            app.difficulty = 'MEDIUM'
            print(f'Difficulty Changed to: {app.difficulty}')
        if app.hardDifficultyButton.mouseInButton(mouseX, mouseY):
            app.difficulty = 'HARD'
            print(f'Difficulty Changed to: {app.difficulty}')


    if (app.gameState == 'titleScreen' and app.playButton.mouseInButton(mouseX,mouseY)
        and app.difficulty != None):
    
        app.gameState = 'playing'
        resetGame(app)
        if not app.mobsSpawned:
            app.stage.spawnEnemies(app)
            app.mobsSpawned = not app.mobsSpawned


def onMouseMove(app, mouseX, mouseY):
    app.mouseX = mouseX
    app.mouseY = mouseY

def onStep(app):
    if app.gameState == 'playing':
        if app.keysHeld: # movement
            app.player1.move(app,app.keysHeld,app.map)
        updateGameObjects(app)
        app.stage.update(app)
                
        if app.player1.health <= 0:
            app.gameState = 'gameOver'

    for bullet in app.activePlayerBullets:
        bullet.move(app)
    

def main():
    runApp()

main()

cmu_graphics.run()